package pacote;

public class Roteiro {
	
	private String disciplina;
	private String nomeDaAula;
	private String conteudo;
	
	public Roteiro(String disciplina, String nomeDaAula, String conteudo) {
		this.disciplina = disciplina;
		this.nomeDaAula = nomeDaAula;
		this.conteudo = conteudo;
	}

	public String exibir() {
		return "Disciplina: " + disciplina + ". Aula: " + nomeDaAula + ". Conteudo: " + conteudo;
	}
	
	
}
