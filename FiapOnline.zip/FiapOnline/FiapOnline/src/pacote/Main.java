package pacote;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String args[]) {
		Scanner leitor = new Scanner(System.in);
		
		System.out.println("Bem vindo professor! Por favor, digite seu nome:");
		String nomeProfessor = leitor.nextLine();
		
		System.out.println("Olá prof." + nomeProfessor);
		
		int opcao = 1;
		ArrayList<Roteiro> roteiros = new ArrayList<>();
		while(opcao == 1) {
			System.out.println("Digite a disciplina a ser ministrada:");
			String nomeDisciplina = leitor.nextLine();
			System.out.println("Certo. Informe também o nome da aula:");
			String nomeAula = leitor.nextLine();
			System.out.println("Por último, informe o conteúdo da aula:");
			String conteudoAula = leitor.nextLine();
			
			Roteiro roteiro = new Roteiro(nomeDisciplina, nomeAula, conteudoAula);
			roteiros.add(roteiro);
			
			System.out.println("Roteiro cadastrado Prof. "+nomeProfessor+". Deseja cadastrar mais algum roteiro?");
			opcao = leitor.nextInt();
		}
		
		Professor professor = new Professor(nomeProfessor, roteiros);
		
		System.out.println("Os roteiros cadastrados foram:");
		for(Roteiro roteiro : professor.getRoteiros()) {
			System.out.println(roteiro.exibir());
		}
		
		leitor.close();
	}
}
