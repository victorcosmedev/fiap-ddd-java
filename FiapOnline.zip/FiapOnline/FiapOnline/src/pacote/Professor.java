package pacote;

import java.util.ArrayList;

public class Professor {

	private String nome;
	private ArrayList<Roteiro> roteiros;
	
	public Professor(String nome, ArrayList<Roteiro> roteiros) {
		this.nome = nome;
		this.roteiros = roteiros;
	}

	public ArrayList<Roteiro> getRoteiros() {
		return roteiros;
	}
}
